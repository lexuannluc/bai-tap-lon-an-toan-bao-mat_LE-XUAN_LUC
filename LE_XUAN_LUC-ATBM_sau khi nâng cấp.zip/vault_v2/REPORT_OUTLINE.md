# Khung báo cáo — Đề tài 22: Secure Personal Data Vault (bản nâng cấp)

> Dàn ý theo đúng 13 mục bắt buộc của đề bài (mục 5 hướng dẫn). Đã điền sẵn nội dung tham chiếu
> tới mã nguồn/test — nhóm chỉ cần bổ sung ảnh chụp màn hình, số liệu thực đo và video demo.

## 1. Giới thiệu bài toán
- **Bối cảnh thực tế**: hệ thống lưu trữ CCCD, mã số BHXH, số tài khoản ngân hàng của người dùng
  cho một dịch vụ nội bộ; dữ liệu này nếu rò rỉ có thể bị lạm dụng cho lừa đảo/giả mạo danh tính.
- **Mục tiêu hệ thống**: đảm bảo dữ liệu không bao giờ được lưu ở dạng rõ, chỉ chủ sở hữu hoặc
  người được cấp quyền tường minh mới xem được, và mọi truy cập đều để lại dấu vết không thể xoá.
- **Lý do cần bảo mật**: dữ liệu định danh cá nhân (PII) thuộc nhóm dữ liệu nhạy cảm theo pháp
  luật bảo vệ dữ liệu cá nhân; rủi ro cao khi hệ thống khoá trước lưu mật khẩu admin dạng rõ và
  không có xác thực toàn vẹn.

## 2. Mục tiêu bảo mật
- Tính bí mật: AES-256-GCM cho toàn bộ trường nhạy cảm (`crypto_utils.aes_gcm_encrypt`).
- Tính toàn vẹn: GCM-tag (từng trường) + HMAC-SHA256 (toàn bản ghi) + hash-chain (nhật ký).
- Tính xác thực: scrypt cho mật khẩu, RBAC 3 vai trò, cơ chế cấp quyền có phê duyệt.
- Tính sẵn sàng: SQLite transaction, khoá tài khoản tạm thời thay vì khoá vĩnh viễn.
- Khả năng truy vết: audit log đầy đủ sự kiện + session_id + xác minh chuỗi hash.

## 3. Threat model
| STT | Nội dung | Mô tả |
|---|---|---|
| 1 | Tài sản cần bảo vệ | CCCD, mã BHXH, số tài khoản ngân hàng, mật khẩu người dùng, khoá mã hoá |
| 2 | Người dùng hợp lệ | User (chủ dữ liệu), Admin (vận hành), Auditor (kiểm toán) |
| 3 | Tác nhân tấn công giả định | Kẻ tấn công có quyền truy cập CSDL (đánh cắp file `vault.db`), Admin lạm quyền, kẻ nghe lén/chặn request (replay), kẻ brute-force mật khẩu |
| 4 | Nguy cơ bảo mật | Rò rỉ dữ liệu rõ, sửa ciphertext không bị phát hiện, admin xem dữ liệu không kiểm soát, replay yêu cầu giải mã, dò mật khẩu |
| 5 | Giả định & giới hạn | Giả định tầng mạng có TLS khi triển khai thật; hệ thống không tự chống DDoS; `ROOT_SECRET` được bảo vệ ở tầng hạ tầng (ngoài phạm vi đề tài) |

## 4. Kiến trúc hệ thống
- **Client**: trình duyệt, không lưu trạng thái nhạy cảm (không dùng localStorage).
- **Server**: Flask (Python), phân lớp `app.py` (routes) / `auth.py` (RBAC) / `crypto_utils.py`
  (mật mã) / `db.py` (truy cập dữ liệu).
- **Database**: SQLite (`vault.db`) — 6 bảng: `users`, `vault_records`, `access_grants`,
  `used_nonces`, `login_attempts`, `audit_logs`.
- Sơ đồ kiến trúc: xem `docs/architecture.md` hoặc vẽ lại bằng draw.io dựa trên mục 1 của README.

## 5. Thiết kế giao thức / luồng xử lý
Luồng chính cần vẽ sequence diagram:
1. **Đăng ký**: user → server: tạo tài khoản (scrypt) + mã hoá AES-GCM + ghi HMAC → lưu SQLite.
2. **User tự xem dữ liệu**: GET `/vault` (server cấp nonce) → POST `/vault/reveal` (mật khẩu +
   nonce) → verify HMAC → AES-GCM decrypt → log `VIEW_OWN_DATA`.
3. **Admin xin quyền & giải mã**: POST `/admin/grant/request` → Auditor POST
   `/auditor/grant/<id>/approve` (cấp hạn 10 phút) → GET `/admin/decrypt/<id>` (cấp nonce) → POST
   `/admin/decrypt/<id>/reveal` (tiêu thụ nonce + grant một lần) → log `DECRYPT_SUCCESS`.
4. **Phát hiện replay**: gửi lại đúng nonce/­grant đã dùng → `consume_nonce` trả `False` → log
   `REPLAY_DETECTED`, từ chối.

## 6. Thuật toán và thư viện sử dụng
- **Mã hoá**: AES-256-GCM (`pycryptodome`), chính; Triple DES-CBC chỉ minh hoạ/benchmark.
- **Hash/HMAC**: HMAC-SHA256 cho toàn vẹn bản ghi và hash-chain log.
- **Cơ chế quản lý khoá**: HKDF (RFC 5869) suy dẫn khoá con từ `ROOT_SECRET`.
- **Thư viện lập trình**: Flask, pycryptodome, python-dotenv, werkzeug.security (scrypt), pytest.
- **Lý do lựa chọn**: GCM cung cấp cả mã hoá và xác thực trong một bước (tránh lỗi "encrypt rồi
  quên xác thực"); scrypt chống lại tấn công dùng phần cứng chuyên dụng tốt hơn SHA-256 thuần.

## 7. Mô tả chức năng đã cài đặt
- Chức năng nền: đăng ký, đăng nhập, xem/sửa/xoá dữ liệu cá nhân (mã hoá).
- Chức năng nâng cấp: RBAC 3 vai trò, cấp quyền giải mã có phê duyệt + hết hạn + dùng một lần,
  chống replay, audit log hash-chain, khoá tài khoản sau đăng nhập sai, trang benchmark.
- Giao diện: xem mục 4 README (thiết kế "Vault Ledger").

## 8. Phân tích mã nguồn
- Cấu trúc thư mục: xem `README.md` mục 1.
- Giải thích lý do chọn kiến trúc theo lớp (routes / auth / crypto / db) để mã nguồn dễ kiểm thử
  độc lập (unit test `crypto_utils` không cần khởi động Flask).
- Cách chạy chương trình: xem `README.md` mục 5.

## 9. Kiểm thử chức năng
Xem `tests/test_security.py`. Chèn ảnh/log kết quả `pytest tests/ -v` (13/13 PASSED) vào báo cáo.

## 10. Kiểm thử bảo mật
| Test case | Hàm kiểm thử | Kết quả kỳ vọng |
|---|---|---|
| Dữ liệu bị sửa (ciphertext) | `test_aes_gcm_tamper_detected` | `IntegrityError` |
| Sai khoá/tag | `test_aes_gcm_wrong_tag_detected` | `IntegrityError` |
| Sai chữ ký/HMAC | `test_hmac_record_tamper_detected` | HMAC không khớp |
| Replay | `test_replay_nonce_cannot_be_reused` | nonce thứ 2 bị từ chối |
| Hết hạn quyền/nonce | `test_expired_nonce_rejected` | từ chối |
| Sai quyền (admin chưa được cấp) | `test_admin_cannot_decrypt_without_approved_grant` | 403/redirect + thông báo |
| Auditor không được giải mã | `test_auditor_role_cannot_reach_admin_decrypt_routes` | chặn ở `roles_required` |
| Log bị giả mạo | `test_audit_log_chain_detects_tampering` | `verify_log_chain` trả `False` |

## 11. Benchmark hiệu năng
Chạy `/admin/benchmark` (hoặc `crypto_utils.benchmark()`), điền bảng số liệu thời gian mã
hoá/giải mã AES-256-GCM và 3DES-CBC (500 vòng lặp), kích thước bản mã. So sánh trước/sau nâng
cấp: bài khoá trước dùng AES-CBC (không tag) — nêu rõ chi phí thêm ~16 byte tag của GCM đổi lấy
khả năng phát hiện giả mạo.

## 12. Bảng kế thừa và nâng cấp
Xem README.md mục 6 (đã điền sẵn, đối chiếu với bài khoá trước theo yêu cầu mục 6 hướng dẫn).

## 13. Kết luận và hướng phát triển
Xem README.md mục 7 ("Hạn chế & hướng phát triển").
