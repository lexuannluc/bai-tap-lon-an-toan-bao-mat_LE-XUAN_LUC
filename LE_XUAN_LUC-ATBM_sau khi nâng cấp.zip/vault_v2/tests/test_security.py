# -*- coding: utf-8 -*-
"""
Bộ test case bắt buộc (mục 9 & 10 của đề bài):
  - Test case chức năng: mã hoá/giải mã đúng, luồng đăng ký/đăng nhập/xem dữ liệu.
  - Test case bảo mật: dữ liệu bị sửa, sai khoá, sai HMAC, replay, sai quyền/hết hạn.
"""
import base64
import time

import pytest

import crypto_utils as cx
import db


# ------------------------------------------------------------- 1) Mật mã --
def test_aes_gcm_roundtrip():
    blob = cx.aes_gcm_encrypt("079203001234")
    assert cx.aes_gcm_decrypt(blob) == "079203001234"


def test_aes_gcm_tamper_detected():
    blob = cx.aes_gcm_encrypt("079203001234")
    raw = bytearray(base64.b64decode(blob["ciphertext"]))
    raw[0] ^= 0xFF  # lật 1 bit trong bản mã
    blob["ciphertext"] = base64.b64encode(bytes(raw)).decode()
    with pytest.raises(cx.IntegrityError):
        cx.aes_gcm_decrypt(blob)


def test_aes_gcm_wrong_tag_detected():
    blob = cx.aes_gcm_encrypt("079203001234")
    blob["tag"] = base64.b64encode(b"0" * 16).decode()
    with pytest.raises(cx.IntegrityError):
        cx.aes_gcm_decrypt(blob)


def test_hmac_record_tamper_detected():
    fields = ["alice", "Alice Nguyen", "n1", "c1", "t1", "n2", "c2", "t2", "n3", "c3", "t3",
              "Vietcombank", "2026-01-01 00:00:00", "2026-01-01 00:00:00"]
    tag = cx.compute_record_hmac(fields)
    assert cx.verify_record_hmac(fields, tag) is True
    tampered = list(fields)
    tampered[11] = "Techcombank"  # sửa bank_name (trường không mã hoá)
    assert cx.verify_record_hmac(tampered, tag) is False


def test_password_not_stored_or_hashed_as_plain_sha256():
    h = cx.hash_password("MyS3cret!Pass")
    assert "sha256$" not in h  # không phải Werkzeug legacy salted-sha256
    assert h.startswith("scrypt:")
    assert cx.verify_password(h, "MyS3cret!Pass") is True
    assert cx.verify_password(h, "wrong-password") is False


# ---------------------------------------------------------- 2) Chống replay
def test_replay_nonce_cannot_be_reused():
    with db.get_conn() as conn:
        db.store_nonce(conn, "nonce-abc", "reveal_own", "alice", ttl_seconds=60)
        first = db.consume_nonce(conn, "nonce-abc", "reveal_own", "alice")
        second = db.consume_nonce(conn, "nonce-abc", "reveal_own", "alice")  # replay
    assert first is True
    assert second is False, "Việc dùng lại cùng 1 nonce phải bị từ chối (phát hiện replay)"


def test_expired_nonce_rejected():
    with db.get_conn() as conn:
        db.store_nonce(conn, "nonce-exp", "reveal_own", "alice", ttl_seconds=-1)
        ok = db.consume_nonce(conn, "nonce-exp", "reveal_own", "alice")
    assert ok is False


# ------------------------------------------------------- 3) Luồng ứng dụng
def register_user(client, username="alice", password="AlicePass123!"):
    return client.post("/register", data={
        "username": username, "password": password, "name": "Alice Nguyen",
        "cmnd": "079203001234", "social_insurance": "1234567890",
        "bank_account": "0011002233", "bank_name": "Vietcombank",
    }, follow_redirects=True)


def login(client, username, password):
    return client.post("/login", data={"username": username, "password": password}, follow_redirects=True)


def test_register_login_and_view_own_masked_data(client):
    register_user(client)
    login(client, "alice", "AlicePass123!")
    resp = client.get("/vault")
    assert resp.status_code == 200
    assert b"234" in resp.data          # 3 ký tự cuối CCCD được giữ lại khi hiển thị (masked)
    assert b"079203001234" not in resp.data  # KHÔNG được hiển thị CCCD đầy đủ ở dạng rõ


def test_wrong_login_locks_account_after_max_fails(client):
    register_user(client, "bob", "BobPass123!")
    for _ in range(5):
        login(client, "bob", "wrong-password")
    resp = login(client, "bob", "BobPass123!")  # đúng mật khẩu nhưng đã bị khoá
    assert "tạm khoá".encode("utf-8") in resp.data


def _make_admin_and_auditor():
    with db.get_conn() as conn:
        conn.execute("INSERT INTO users (username,password_hash,role,created_at) VALUES (?,?,?,datetime('now'))",
                     ("admin1", cx.hash_password("AdminPass123!"), "admin"))
        conn.execute("INSERT INTO users (username,password_hash,role,created_at) VALUES (?,?,?,datetime('now'))",
                     ("audit1", cx.hash_password("AuditPass123!"), "auditor"))


def test_admin_cannot_decrypt_without_approved_grant(client):
    register_user(client, "carol", "CarolPass123!")
    _make_admin_and_auditor()
    login(client, "admin1", "AdminPass123!")
    with db.get_conn() as conn:
        record_id = conn.execute("SELECT id FROM vault_records WHERE owner_username='carol'").fetchone()["id"]
    resp = client.get(f"/admin/decrypt/{record_id}", follow_redirects=True)
    assert "chưa được cấp quyền".encode("utf-8") in resp.data


def test_admin_can_decrypt_only_after_auditor_approval_and_grant_is_single_use(client):
    register_user(client, "dave", "DavePass123!")
    _make_admin_and_auditor()

    login(client, "admin1", "AdminPass123!")
    with db.get_conn() as conn:
        record_id = conn.execute("SELECT id FROM vault_records WHERE owner_username='dave'").fetchone()["id"]
    client.post("/admin/grant/request", data={"record_id": record_id, "reason": "Xử lý khiếu nại"},
                follow_redirects=True)
    client.get("/logout")

    login(client, "audit1", "AuditPass123!")
    with db.get_conn() as conn:
        grant_id = conn.execute("SELECT id FROM access_grants WHERE record_id=?", (record_id,)).fetchone()["id"]
    client.post(f"/auditor/grant/{grant_id}/approve", follow_redirects=True)
    client.get("/logout")

    login(client, "admin1", "AdminPass123!")
    page = client.get(f"/admin/decrypt/{record_id}")
    assert page.status_code == 200
    # trích nonce từ form ẩn
    body = page.data.decode()
    nonce = body.split('name="nonce" value="')[1].split('"')[0]
    first = client.post(f"/admin/decrypt/{record_id}/reveal",
                         data={"grant_id": grant_id, "nonce": nonce}, follow_redirects=True)
    assert "Dave".encode() in first.data or "Dữ liệu đã giải mã".encode("utf-8") in first.data

    # Grant đã dùng 1 lần -> truy cập lại phải bị từ chối (không mặc định cho xem)
    second = client.get(f"/admin/decrypt/{record_id}", follow_redirects=True)
    assert "chưa được cấp quyền".encode("utf-8") in second.data


def test_auditor_role_cannot_reach_admin_decrypt_routes(client):
    register_user(client, "erin", "ErinPass123!")
    _make_admin_and_auditor()
    with db.get_conn() as conn:
        record_id = conn.execute("SELECT id FROM vault_records WHERE owner_username='erin'").fetchone()["id"]
    login(client, "audit1", "AuditPass123!")
    resp = client.get(f"/admin/decrypt/{record_id}", follow_redirects=True)
    assert "không có quyền truy cập".encode("utf-8") in resp.data


# ------------------------------------------------------ 4) Toàn vẹn nhật ký
def test_audit_log_chain_detects_tampering(client):
    register_user(client, "frank", "FrankPass123!")
    with db.get_conn() as conn:
        ok, broken_at = db.verify_log_chain(conn)
        assert ok is True
        # Giả lập kẻ tấn công sửa trực tiếp 1 dòng log trong CSDL
        conn.execute("UPDATE audit_logs SET detail='đã bị xoá dấu vết' WHERE id=(SELECT MIN(id) FROM audit_logs)")
        ok2, broken_at2 = db.verify_log_chain(conn)
        assert ok2 is False
        assert broken_at2 is not None
