# -*- coding: utf-8 -*-
import os
import secrets
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Thiết lập biến môi trường TRƯỚC khi import app/config/db, để dùng DB tạm
# và khoá ngẫu nhiên riêng cho mỗi phiên kiểm thử (không đụng tới vault.db thật).
_tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["VAULT_DB_PATH"] = _tmp_db.name
os.environ["FLASK_SECRET_KEY"] = secrets.token_hex(32)
os.environ["ROOT_SECRET"] = secrets.token_hex(32)
os.environ["APP_SALT"] = secrets.token_hex(16)

import app as flask_app_module  # noqa: E402
import db  # noqa: E402
import crypto_utils as cx  # noqa: E402


@pytest.fixture()
def client():
    flask_app_module.app.config.update(TESTING=True)
    with flask_app_module.app.test_client() as c:
        yield c


@pytest.fixture(autouse=True)
def clean_tables():
    with db.get_conn() as conn:
        for t in ["access_grants", "vault_records", "users", "used_nonces", "login_attempts", "audit_logs"]:
            conn.execute(f"DELETE FROM {t}")
    yield
