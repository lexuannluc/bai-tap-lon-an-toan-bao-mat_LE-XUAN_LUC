# -*- coding: utf-8 -*-
"""
crypto_utils.py
================
Toàn bộ nguyên thuỷ mật mã (cryptographic primitives) của hệ thống Secure
Personal Data Vault. KHÔNG hard-code bất kỳ khoá bí mật nào ở đây — mọi khoá
được suy dẫn (derive) từ một ROOT_SECRET nạp từ biến môi trường (.env), theo
nguyên tắc tách biệt khoá theo mục đích sử dụng (key separation).

Cơ chế mã hoá chính: AES-256-GCM (authenticated encryption) cho toàn bộ dữ
liệu nhạy cảm (CCCD, BHXH, số tài khoản ngân hàng).

Triple DES (3DES-CBC) CHỈ được giữ lại như một cơ chế minh hoạ/so sánh
(benchmark) với thuật toán cũ — không được dùng để bảo vệ dữ liệu thật
trong vault (xem yêu cầu 4.1 của đề bài: "TripleDES chỉ nên dùng để so sánh
hoặc chế độ legacy").

Một lớp HMAC-SHA256 độc lập được thêm vào ở cấp bản ghi (record-level) để
phát hiện việc bản ghi bị chỉnh sửa/thay thế (kể cả các trường không mã hoá
như bank_name, created_at) — đây là lớp phòng thủ theo chiều sâu bổ sung cho
GCM-tag vốn chỉ bảo vệ từng trường mã hoá riêng lẻ.
"""
import base64
import binascii
import hashlib
import hmac
import os
import time

from Crypto.Cipher import AES, DES3
from Crypto.Hash import SHA256 as CryptoSHA256
from Crypto.Protocol.KDF import HKDF
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from werkzeug.security import generate_password_hash, check_password_hash


class CryptoError(Exception):
    """Lỗi mật mã tổng quát (giải mã thất bại, tag không hợp lệ, v.v.)"""


class IntegrityError(CryptoError):
    """Dữ liệu bị sửa đổi / tag hoặc HMAC không hợp lệ."""


# --------------------------------------------------------------------------
# 1) QUẢN LÝ KHOÁ (KEY MANAGEMENT)
# --------------------------------------------------------------------------
# ROOT_SECRET: khoá gốc duy nhất, KHÔNG BAO GIỜ được ghi cứng trong mã nguồn.
# Nó chỉ tồn tại trong file .env (không commit lên git) hoặc trong một trình
# quản lý bí mật thực sự (Vault/Secret Manager) khi triển khai production.
#
# Từ ROOT_SECRET, ta dùng HKDF (HMAC-based Key Derivation Function, RFC 5869)
# để suy dẫn ra các khoá con theo từng mục đích (key separation), mỗi khoá
# gắn với một "info label" riêng biệt. Nếu cần "xoay khoá" (key rotation),
# ta chỉ cần thay ROOT_SECRET / thêm KEY_VERSION vào label mà không cần đổi
# kiến trúc.
_ROOT_SECRET = None
_APP_SALT = None
_KEY_VERSION = "v1"


def init_keys(root_secret_hex: str, app_salt_hex: str):
    global _ROOT_SECRET, _APP_SALT
    try:
        _ROOT_SECRET = binascii.unhexlify(root_secret_hex)
        _APP_SALT = binascii.unhexlify(app_salt_hex)
    except Exception as exc:
        raise ValueError(
            "ROOT_SECRET / APP_SALT phải là chuỗi hex hợp lệ. "
            "Hãy chạy `python init_db.py --gen-keys` để tạo mới."
        ) from exc
    if len(_ROOT_SECRET) < 32:
        raise ValueError("ROOT_SECRET phải có ít nhất 32 byte (64 ký tự hex).")


def _derive_key(label: str, length: int) -> bytes:
    if _ROOT_SECRET is None:
        raise RuntimeError("Chưa gọi init_keys() để nạp khoá gốc.")
    info = f"{_KEY_VERSION}:{label}".encode()
    return HKDF(_ROOT_SECRET, length, _APP_SALT, CryptoSHA256, 1, context=info)


def aes_field_key() -> bytes:
    return _derive_key("aes-gcm-field-encryption", 32)  # AES-256


def hmac_record_key() -> bytes:
    return _derive_key("record-integrity-hmac", 32)


def legacy_3des_key() -> bytes:
    # Chỉ dùng cho mục đích minh hoạ / benchmark so sánh thuật toán cũ.
    return _derive_key("legacy-3des-demo-only", 24)


def audit_chain_key() -> bytes:
    return _derive_key("audit-log-hash-chain", 32)


def reveal_token_key() -> bytes:
    return _derive_key("reveal-token-signing", 32)


# --------------------------------------------------------------------------
# 2) AES-256-GCM — cơ chế mã hoá dữ liệu nhạy cảm chính
# --------------------------------------------------------------------------
def aes_gcm_encrypt(plaintext: str) -> dict:
    """Mã hoá một trường dữ liệu, trả về dict base64: nonce, ciphertext, tag."""
    key = aes_field_key()
    nonce = get_random_bytes(12)  # 96-bit nonce khuyến nghị cho GCM
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))
    return {
        "nonce": base64.b64encode(nonce).decode(),
        "ciphertext": base64.b64encode(ct).decode(),
        "tag": base64.b64encode(tag).decode(),
    }


def aes_gcm_decrypt(blob: dict) -> str:
    """Giải mã + xác thực tag. Ném IntegrityError nếu dữ liệu đã bị sửa."""
    key = aes_field_key()
    try:
        nonce = base64.b64decode(blob["nonce"])
        ct = base64.b64decode(blob["ciphertext"])
        tag = base64.b64decode(blob["tag"])
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        pt = cipher.decrypt_and_verify(ct, tag)
        return pt.decode("utf-8")
    except (ValueError, KeyError, binascii.Error) as exc:
        raise IntegrityError("Xác thực AES-GCM thất bại: dữ liệu có thể đã bị sửa đổi.") from exc


# --------------------------------------------------------------------------
# 3) Triple DES - CBC — CHỈ DÙNG ĐỂ MINH HOẠ / BENCHMARK (không xác thực)
# --------------------------------------------------------------------------
def des3_cbc_encrypt_legacy(plaintext: str) -> str:
    key = legacy_3des_key()
    iv = get_random_bytes(8)
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    padded = pad(plaintext.encode("utf-8"), DES3.block_size)
    ct = cipher.encrypt(padded)
    return base64.b64encode(iv + ct).decode()


def des3_cbc_decrypt_legacy(blob_b64: str) -> str:
    key = legacy_3des_key()
    raw = base64.b64decode(blob_b64)
    iv, ct = raw[:8], raw[8:]
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    pt = unpad(cipher.decrypt(ct), DES3.block_size)
    return pt.decode("utf-8")


# --------------------------------------------------------------------------
# 4) HMAC-SHA256 toàn vẹn bản ghi (record-level integrity)
# --------------------------------------------------------------------------
def compute_record_hmac(canonical_fields: list) -> str:
    """canonical_fields: danh sách chuỗi (đã cố định thứ tự) đại diện toàn bộ
    nội dung bản ghi (kể cả phần không mã hoá). Trả về hex digest."""
    key = hmac_record_key()
    msg = "||".join(canonical_fields).encode("utf-8")
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def verify_record_hmac(canonical_fields: list, expected_hex: str) -> bool:
    actual = compute_record_hmac(canonical_fields)
    return hmac.compare_digest(actual, expected_hex)


# --------------------------------------------------------------------------
# 5) Băm mật khẩu — KHÔNG BAO GIỜ dùng SHA-256 trần cho mật khẩu.
#    Dùng scrypt (qua werkzeug.security), có salt ngẫu nhiên + cost factor.
# --------------------------------------------------------------------------
def hash_password(password: str) -> str:
    return generate_password_hash(password, method="scrypt")


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return check_password_hash(password_hash, password)
    except Exception:
        return False


# --------------------------------------------------------------------------
# 6) Audit-log hash chaining (bằng chứng chống giả mạo cho chính log)
# --------------------------------------------------------------------------
def compute_log_entry_hash(prev_hash: str, timestamp: str, actor: str,
                            event_type: str, target: str, detail: str) -> str:
    key = audit_chain_key()
    msg = f"{prev_hash}|{timestamp}|{actor}|{event_type}|{target}|{detail}".encode()
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


# --------------------------------------------------------------------------
# 7) Benchmark tiện ích (đo thời gian mã hoá/giải mã) — dùng cho mục 11 báo cáo
# --------------------------------------------------------------------------
def benchmark(iterations: int = 1000, sample: str = "079203001234"):
    results = {}

    t0 = time.perf_counter()
    blobs = [aes_gcm_encrypt(sample) for _ in range(iterations)]
    t1 = time.perf_counter()
    for b in blobs:
        aes_gcm_decrypt(b)
    t2 = time.perf_counter()
    sample_ct_len = len(base64.b64decode(blobs[0]["ciphertext"])) + len(base64.b64decode(blobs[0]["tag"])) + 12
    results["AES-256-GCM"] = {
        "encrypt_s": round(t1 - t0, 4),
        "decrypt_s": round(t2 - t1, 4),
        "ciphertext_bytes": sample_ct_len,
    }

    t0 = time.perf_counter()
    legacy_blobs = [des3_cbc_encrypt_legacy(sample) for _ in range(iterations)]
    t1 = time.perf_counter()
    for b in legacy_blobs:
        des3_cbc_decrypt_legacy(b)
    t2 = time.perf_counter()
    results["3DES-CBC (legacy demo)"] = {
        "encrypt_s": round(t1 - t0, 4),
        "decrypt_s": round(t2 - t1, 4),
        "ciphertext_bytes": len(base64.b64decode(legacy_blobs[0])),
    }
    return results
