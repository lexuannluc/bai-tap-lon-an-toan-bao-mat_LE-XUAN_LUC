# -*- coding: utf-8 -*-
"""
init_db.py — Script khởi tạo:
  1) Sinh khoá bí mật mới (ROOT_SECRET, APP_SALT, FLASK_SECRET_KEY) nếu chưa có .env
  2) Khởi tạo schema SQLite
  3) Seed 1 tài khoản admin và 1 tài khoản auditor mặc định (BẮT BUỘC đổi mật khẩu
     ngay sau khi chạy lần đầu trong môi trường thật)

Chạy:
    python init_db.py --gen-keys      # tạo file .env mới với khoá ngẫu nhiên
    python init_db.py --seed          # tạo schema + tài khoản admin/auditor mẫu
"""
import argparse
import secrets
import sys

ENV_TEMPLATE = """# Sinh tự động bởi init_db.py --gen-keys — KHÔNG commit file này lên git!
FLASK_SECRET_KEY={flask_secret}
ROOT_SECRET={root_secret}
APP_SALT={app_salt}
REVEAL_TOKEN_TTL_SECONDS=60
GRANT_TTL_SECONDS=600
LOGIN_MAX_FAILS=5
LOGIN_LOCKOUT_SECONDS=900
"""


def gen_keys():
    import os
    if os.path.exists(".env"):
        print(".env đã tồn tại — không ghi đè. Xoá thủ công nếu muốn tạo khoá mới.")
        return
    content = ENV_TEMPLATE.format(
        flask_secret=secrets.token_hex(32),
        root_secret=secrets.token_hex(32),
        app_salt=secrets.token_hex(16),
    )
    with open(".env", "w", encoding="utf-8") as f:
        f.write(content)
    print("Đã tạo .env với khoá ngẫu nhiên mới.")


def seed():
    import config
    import db
    import crypto_utils as cx

    cx.init_keys(config.ROOT_SECRET, config.APP_SALT)
    db.init_db()

    with db.get_conn() as conn:
        for username, role, pw in [
            ("admin", "admin", "ChangeMe_Admin!2026"),
            ("auditor", "auditor", "ChangeMe_Auditor!2026"),
        ]:
            exists = conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone()
            if exists:
                print(f"Tài khoản '{username}' đã tồn tại, bỏ qua.")
                continue
            import time
            conn.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)",
                (username, cx.hash_password(pw), role, time.strftime("%Y-%m-%d %H:%M:%S")),
            )
            print(f"Đã tạo tài khoản {role}: username='{username}'  password='{pw}'  (ĐỔI MẬT KHẨU NGAY!)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gen-keys", action="store_true")
    parser.add_argument("--seed", action="store_true")
    args = parser.parse_args()
    if not args.gen_keys and not args.seed:
        parser.print_help()
        sys.exit(0)
    if args.gen_keys:
        gen_keys()
    if args.seed:
        seed()
