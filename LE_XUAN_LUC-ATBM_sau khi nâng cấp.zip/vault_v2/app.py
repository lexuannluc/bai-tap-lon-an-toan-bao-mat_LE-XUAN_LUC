# -*- coding: utf-8 -*-
"""
Secure Personal Data Vault — Đề tài 22 (bản nâng cấp)
Nâng cấp từ dự án "ma-hoa-thong-tin-nhay-cam-main" (TripleDES + AES-CBC,
lưu JSON phẳng, mật khẩu admin dạng rõ) lên một hệ thống đáp ứng đầy đủ yêu
cầu kỹ thuật bắt buộc của bài tập lớn FIT4012 (Secure System Upgrade
Challenge): AES-256-GCM là cơ chế mã hoá chính, phân quyền 3 vai trò
(User/Admin/Auditor), cấp quyền giải mã theo từng bản ghi cho Admin, chống
replay bằng nonce một lần dùng, ghi audit log có hash-chain chống giả mạo,
băm mật khẩu bằng scrypt, và không hard-code khoá bí mật trong mã nguồn.
"""
import time
import uuid
import webbrowser
import threading
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort

import config
import db
import crypto_utils as cx
from auth import login_required, roles_required, current_user

app = Flask(__name__)
app.secret_key = config.FLASK_SECRET_KEY
cx.init_keys(config.ROOT_SECRET, config.APP_SALT)
db.init_db()


# ---------------------------------------------------------------- Helpers
def mask(value: str, keep: int = 3) -> str:
    if not value:
        return ""
    if len(value) <= keep:
        return "*" * len(value)
    return "*" * (len(value) - keep) + value[-keep:]


def log(event_type, target=None, detail=None):
    with db.get_conn() as conn:
        db.append_audit_log(
            conn,
            session.get("username", "anonymous"),
            session.get("role"),
            session.get("sid"),
            event_type,
            target,
            detail,
            request.remote_addr,
        )


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def record_canonical_fields(row_dict):
    return [
        row_dict["owner_username"], row_dict["display_name"],
        row_dict["cmnd_nonce"], row_dict["cmnd_ciphertext"], row_dict["cmnd_tag"],
        row_dict["bhxh_nonce"], row_dict["bhxh_ciphertext"], row_dict["bhxh_tag"],
        row_dict["bank_nonce"], row_dict["bank_ciphertext"], row_dict["bank_tag"],
        row_dict["bank_name"], row_dict["created_at"], row_dict["updated_at"],
    ]


def build_encrypted_payload(display_name, cmnd, bhxh, bank_account, bank_name,
                             owner, created_at, updated_at):
    c = cx.aes_gcm_encrypt(cmnd)
    b = cx.aes_gcm_encrypt(bhxh)
    k = cx.aes_gcm_encrypt(bank_account)
    payload = {
        "owner_username": owner, "display_name": display_name,
        "cmnd_nonce": c["nonce"], "cmnd_ciphertext": c["ciphertext"], "cmnd_tag": c["tag"],
        "bhxh_nonce": b["nonce"], "bhxh_ciphertext": b["ciphertext"], "bhxh_tag": b["tag"],
        "bank_nonce": k["nonce"], "bank_ciphertext": k["ciphertext"], "bank_tag": k["tag"],
        "bank_name": bank_name, "created_at": created_at, "updated_at": updated_at,
    }
    payload["record_hmac"] = cx.compute_record_hmac(record_canonical_fields(payload))
    return payload


def decrypt_record(row):
    """Giải mã 1 bản ghi vault_records (sqlite3.Row). Kiểm tra HMAC trước.
    Ném IntegrityError nếu bản ghi bị sửa (kể cả các trường không mã hoá)."""
    row_dict = dict(row)
    if not cx.verify_record_hmac(record_canonical_fields(row_dict), row_dict["record_hmac"]):
        raise cx.IntegrityError("HMAC bản ghi không khớp — dữ liệu đã bị chỉnh sửa trái phép.")
    cmnd = cx.aes_gcm_decrypt({"nonce": row["cmnd_nonce"], "ciphertext": row["cmnd_ciphertext"], "tag": row["cmnd_tag"]})
    bhxh = cx.aes_gcm_decrypt({"nonce": row["bhxh_nonce"], "ciphertext": row["bhxh_ciphertext"], "tag": row["bhxh_tag"]})
    bank = cx.aes_gcm_decrypt({"nonce": row["bank_nonce"], "ciphertext": row["bank_ciphertext"], "tag": row["bank_tag"]})
    return {"cmnd": cmnd, "social_insurance": bhxh, "bank_account": bank, "bank_name": row["bank_name"]}


def validate_vault_fields(cmnd, bhxh, bank_account):
    if not (cmnd.isdigit() and 9 <= len(cmnd) <= 12):
        return "Số CCCD/CMND phải là số và có 9-12 chữ số!"
    if not (bhxh.isdigit() and len(bhxh) == 10):
        return "Mã số BHXH phải là số và đúng 10 chữ số!"
    if not (bank_account.isdigit() and 6 <= len(bank_account) <= 32):
        return "Số tài khoản ngân hàng phải là số và từ 6 đến 32 chữ số!"
    return None


# ------------------------------------------------------------------ Home
@app.route("/")
def home():
    return render_template("index.html", user=current_user())


# --------------------------------------------------------------- Register
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        display_name = request.form.get("name", "").strip()
        cmnd = request.form.get("cmnd", "").strip()
        bhxh = request.form.get("social_insurance", "").strip()
        bank_account = request.form.get("bank_account", "").strip()
        bank_name = request.form.get("bank_name", "").strip()

        if not username or len(password) < 8:
            flash("Tên đăng nhập không hợp lệ hoặc mật khẩu phải từ 8 ký tự trở lên!", "danger")
            return redirect(url_for("register"))
        err = validate_vault_fields(cmnd, bhxh, bank_account)
        if err:
            flash(err, "danger")
            return redirect(url_for("register"))

        with db.get_conn() as conn:
            exists = conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone()
            if exists:
                flash("Tên đăng nhập đã tồn tại!", "danger")
                return redirect(url_for("register"))
            conn.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)",
                (username, cx.hash_password(password), "user", now_str()),
            )
            ts = now_str()
            payload = build_encrypted_payload(display_name, cmnd, bhxh, bank_account, bank_name,
                                               username, ts, ts)
            conn.execute(
                """INSERT INTO vault_records
                   (owner_username, display_name, cmnd_nonce, cmnd_ciphertext, cmnd_tag,
                    bhxh_nonce, bhxh_ciphertext, bhxh_tag, bank_nonce, bank_ciphertext, bank_tag,
                    bank_name, record_hmac, created_at, updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (payload["owner_username"], payload["display_name"],
                 payload["cmnd_nonce"], payload["cmnd_ciphertext"], payload["cmnd_tag"],
                 payload["bhxh_nonce"], payload["bhxh_ciphertext"], payload["bhxh_tag"],
                 payload["bank_nonce"], payload["bank_ciphertext"], payload["bank_tag"],
                 payload["bank_name"], payload["record_hmac"], ts, ts),
            )
            db.append_audit_log(conn, username, "user", None, "ACCOUNT_CREATED", username,
                                 "Đăng ký tài khoản mới + tạo bản ghi vault (đã mã hoá)", request.remote_addr)
        flash("Đăng ký thành công! Hãy đăng nhập.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


# ------------------------------------------------------------------ Login
PORTALS = {
    "user": "Người dùng",
    "admin": "Quản trị viên",
    "auditor": "Kiểm toán viên",
}


@app.route("/login", methods=["GET", "POST"])
def login():
    # Cổng đăng nhập được chọn từ trang chủ (user/admin/auditor). Không bắt
    # buộc — /login không kèm tham số vẫn hoạt động như trước (giao diện
    # trung lập), để không phá vỡ các luồng đăng nhập hiện có.
    portal = request.values.get("role", "").strip().lower()
    if portal not in PORTALS:
        portal = ""

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with db.get_conn() as conn:
            locked, until = db.is_locked_out(conn, username)
            if locked:
                remaining = int(until - time.time())
                flash(f"Tài khoản tạm khoá do đăng nhập sai nhiều lần. Thử lại sau {remaining//60+1} phút.", "danger")
                db.append_audit_log(conn, username, None, None, "LOGIN_BLOCKED_LOCKOUT", username,
                                     "Đăng nhập bị chặn do khoá tạm thời", request.remote_addr)
                return redirect(url_for("login", role=portal) if portal else url_for("login"))

            row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            if row and cx.verify_password(row["password_hash"], password):
                # Cổng người dùng chọn phải khớp vai trò thật của tài khoản —
                # tách bạch giao diện theo vai trò như yêu cầu phân quyền tối thiểu.
                if portal and row["role"] != portal:
                    db.append_audit_log(conn, username, row["role"], None, "LOGIN_PORTAL_MISMATCH",
                                         username,
                                         f"Đăng nhập ở cổng '{PORTALS[portal]}' nhưng tài khoản có vai trò '{row['role']}'",
                                         request.remote_addr)
                    flash(f"Tài khoản này không có vai trò {PORTALS[portal]}. "
                          f"Vui lòng đăng nhập ở đúng cổng dành cho vai trò của bạn.", "danger")
                    return redirect(url_for("login", role=portal))

                db.reset_login_attempts(conn, username)
                session.clear()
                session["username"] = username
                session["role"] = row["role"]
                session["sid"] = uuid.uuid4().hex
                db.append_audit_log(conn, username, row["role"], session["sid"], "LOGIN_SUCCESS",
                                     username, "Tạo phiên làm việc mới", request.remote_addr)
                flash("Đăng nhập thành công!", "success")
                if row["role"] == "admin":
                    return redirect(url_for("admin_dashboard"))
                if row["role"] == "auditor":
                    return redirect(url_for("auditor_dashboard"))
                return redirect(url_for("vault_view"))
            else:
                db.register_login_failure(conn, username, config.LOGIN_LOCKOUT_SECONDS, config.LOGIN_MAX_FAILS)
                db.append_audit_log(conn, username, None, None, "LOGIN_FAIL", username,
                                     "Sai tên đăng nhập hoặc mật khẩu", request.remote_addr)
        flash("Sai tên đăng nhập hoặc mật khẩu!", "danger")
        return redirect(url_for("login", role=portal) if portal else url_for("login"))
    return render_template("login.html", portal=portal, portal_label=PORTALS.get(portal))


@app.route("/logout")
def logout():
    log("LOGOUT", session.get("username"), "Kết thúc phiên làm việc")
    session.clear()
    flash("Đã đăng xuất!", "success")
    return redirect(url_for("home"))


# ------------------------------------------------------------- User vault
@app.route("/vault")
@login_required
@roles_required("user")
def vault_view():
    with db.get_conn() as conn:
        row = conn.execute("SELECT * FROM vault_records WHERE owner_username=?",
                            (session["username"],)).fetchone()
    if not row:
        flash("Không tìm thấy bản ghi.", "danger")
        return redirect(url_for("home"))
    masked = {
        "display_name": row["display_name"],
        "cmnd": mask(cx.aes_gcm_decrypt({"nonce": row["cmnd_nonce"], "ciphertext": row["cmnd_ciphertext"], "tag": row["cmnd_tag"]})),
        "bank_name": row["bank_name"],
        "updated_at": row["updated_at"],
    }
    nonce = uuid.uuid4().hex
    with db.get_conn() as conn:
        db.store_nonce(conn, nonce, "reveal_own", session["username"], config.REVEAL_TOKEN_TTL_SECONDS)
    return render_template("vault.html", record=masked, reveal_nonce=nonce)


@app.route("/vault/reveal", methods=["POST"])
@login_required
@roles_required("user")
def vault_reveal():
    nonce = request.form.get("nonce", "")
    password = request.form.get("password", "")
    with db.get_conn() as conn:
        user_row = conn.execute("SELECT * FROM users WHERE username=?", (session["username"],)).fetchone()
        if not cx.verify_password(user_row["password_hash"], password):
            db.append_audit_log(conn, session["username"], "user", session.get("sid"), "REAUTH_FAIL",
                                 session["username"], "Sai mật khẩu khi xác thực lại để xem dữ liệu", request.remote_addr)
            flash("Sai mật khẩu xác thực lại!", "danger")
            return redirect(url_for("vault_view"))
        ok = db.consume_nonce(conn, nonce, "reveal_own", session["username"])
        if not ok:
            db.append_audit_log(conn, session["username"], "user", session.get("sid"), "REPLAY_DETECTED",
                                 session["username"], f"Token phiên xem dữ liệu không hợp lệ/đã dùng: {nonce}",
                                 request.remote_addr)
            flash("Yêu cầu đã hết hạn hoặc đã được sử dụng (khả năng bị replay). Vui lòng thử lại.", "danger")
            return redirect(url_for("vault_view"))
        row = conn.execute("SELECT * FROM vault_records WHERE owner_username=?",
                            (session["username"],)).fetchone()
        try:
            plain = decrypt_record(row)
        except cx.IntegrityError as exc:
            db.append_audit_log(conn, session["username"], "user", session.get("sid"), "INTEGRITY_FAIL",
                                 session["username"], str(exc), request.remote_addr)
            flash("Cảnh báo bảo mật: dữ liệu của bạn có dấu hiệu bị sửa đổi trái phép!", "danger")
            return redirect(url_for("vault_view"))
        db.append_audit_log(conn, session["username"], "user", session.get("sid"), "VIEW_OWN_DATA",
                             session["username"], "Người dùng xem dữ liệu nhạy cảm của chính mình", request.remote_addr)
    plain["display_name"] = row["display_name"]
    plain["updated_at"] = row["updated_at"]
    return render_template("vault.html", record=None, revealed=plain, reveal_nonce=None)


@app.route("/vault/edit", methods=["GET", "POST"])
@login_required
@roles_required("user")
def vault_edit():
    with db.get_conn() as conn:
        row = conn.execute("SELECT * FROM vault_records WHERE owner_username=?",
                            (session["username"],)).fetchone()
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        with db.get_conn() as conn:
            user_row = conn.execute("SELECT * FROM users WHERE username=?", (session["username"],)).fetchone()
            if not cx.verify_password(user_row["password_hash"], current_password):
                flash("Sai mật khẩu hiện tại — không thể cập nhật dữ liệu nhạy cảm!", "danger")
                return redirect(url_for("vault_edit"))
            cmnd = request.form.get("cmnd", "").strip()
            bhxh = request.form.get("social_insurance", "").strip()
            bank_account = request.form.get("bank_account", "").strip()
            bank_name = request.form.get("bank_name", "").strip()
            display_name = request.form.get("name", "").strip()
            err = validate_vault_fields(cmnd, bhxh, bank_account)
            if err:
                flash(err, "danger")
                return redirect(url_for("vault_edit"))
            ts = now_str()
            payload = build_encrypted_payload(display_name, cmnd, bhxh, bank_account, bank_name,
                                               session["username"], row["created_at"], ts)
            conn.execute(
                """UPDATE vault_records SET display_name=?, cmnd_nonce=?, cmnd_ciphertext=?, cmnd_tag=?,
                   bhxh_nonce=?, bhxh_ciphertext=?, bhxh_tag=?, bank_nonce=?, bank_ciphertext=?, bank_tag=?,
                   bank_name=?, record_hmac=?, updated_at=? WHERE owner_username=?""",
                (payload["display_name"], payload["cmnd_nonce"], payload["cmnd_ciphertext"], payload["cmnd_tag"],
                 payload["bhxh_nonce"], payload["bhxh_ciphertext"], payload["bhxh_tag"],
                 payload["bank_nonce"], payload["bank_ciphertext"], payload["bank_tag"],
                 payload["bank_name"], payload["record_hmac"], ts, session["username"]),
            )
            db.append_audit_log(conn, session["username"], "user", session.get("sid"), "DATA_MODIFIED",
                                 session["username"], "Người dùng cập nhật bản ghi vault của chính mình",
                                 request.remote_addr)
        flash("Cập nhật thành công!", "success")
        return redirect(url_for("vault_view"))
    return render_template("vault_edit.html")


@app.route("/vault/delete", methods=["POST"])
@login_required
@roles_required("user")
def vault_delete():
    password = request.form.get("current_password", "")
    with db.get_conn() as conn:
        user_row = conn.execute("SELECT * FROM users WHERE username=?", (session["username"],)).fetchone()
        if not cx.verify_password(user_row["password_hash"], password):
            flash("Sai mật khẩu — không thể xoá tài khoản!", "danger")
            return redirect(url_for("vault_view"))
        conn.execute("DELETE FROM vault_records WHERE owner_username=?", (session["username"],))
        conn.execute("DELETE FROM users WHERE username=?", (session["username"],))
        db.append_audit_log(conn, session["username"], "user", session.get("sid"), "ACCOUNT_DELETED",
                             session["username"], "Người dùng tự xoá tài khoản và dữ liệu", request.remote_addr)
    session.clear()
    flash("Tài khoản đã được xoá.", "success")
    return redirect(url_for("home"))


# ------------------------------------------------------------ Admin area
@app.route("/admin")
@login_required
@roles_required("admin")
def admin_dashboard():
    with db.get_conn() as conn:
        records = conn.execute("SELECT * FROM vault_records ORDER BY id").fetchall()
        my_grants = conn.execute(
            "SELECT * FROM access_grants WHERE admin_username=? ORDER BY id DESC",
            (session["username"],),
        ).fetchall()
    grants_by_record = {}
    now = time.time()
    for g in my_grants:
        grants_by_record.setdefault(g["record_id"], []).append(g)

    def grant_state(record_id):
        gs = grants_by_record.get(record_id, [])
        for g in gs:
            if g["status"] == "approved":
                exp = time.mktime(time.strptime(g["expires_at"], "%Y-%m-%d %H:%M:%S")) if g["expires_at"] else 0
                if now < exp:
                    return "approved", g["id"]
            if g["status"] == "pending":
                return "pending", g["id"]
        return "none", None

    rows = []
    for r in records:
        state, gid = grant_state(r["id"])
        rows.append({"id": r["id"], "owner": r["owner_username"], "display_name": r["display_name"],
                      "bank_name": r["bank_name"], "updated_at": r["updated_at"],
                      "grant_state": state, "grant_id": gid})
    return render_template("admin_dashboard.html", rows=rows)


@app.route("/admin/grant/request", methods=["POST"])
@login_required
@roles_required("admin")
def admin_grant_request():
    record_id = request.form.get("record_id")
    reason = request.form.get("reason", "").strip()
    if not reason:
        flash("Vui lòng nhập lý do yêu cầu truy cập!", "danger")
        return redirect(url_for("admin_dashboard"))
    with db.get_conn() as conn:
        conn.execute(
            "INSERT INTO access_grants (admin_username, record_id, reason, status, requested_at) VALUES (?,?,?,?,?)",
            (session["username"], record_id, reason, "pending", now_str()),
        )
        db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "GRANT_REQUESTED",
                             f"record:{record_id}", f"Lý do: {reason}", request.remote_addr)
    flash("Đã gửi yêu cầu cấp quyền tới Auditor phê duyệt.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/decrypt/<int:record_id>", methods=["GET"])
@login_required
@roles_required("admin")
def admin_decrypt_page(record_id):
    with db.get_conn() as conn:
        grant = conn.execute(
            """SELECT * FROM access_grants WHERE admin_username=? AND record_id=? AND status='approved'
               ORDER BY id DESC LIMIT 1""",
            (session["username"], record_id),
        ).fetchone()
        record = conn.execute("SELECT * FROM vault_records WHERE id=?", (record_id,)).fetchone()
        if not grant or not record:
            db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "PERMISSION_DENIED",
                                 f"record:{record_id}", "Chưa được cấp quyền giải mã bản ghi này", request.remote_addr)
            flash("Bạn chưa được cấp quyền giải mã bản ghi này. Hãy gửi yêu cầu và chờ Auditor phê duyệt.", "danger")
            return redirect(url_for("admin_dashboard"))
        exp = time.mktime(time.strptime(grant["expires_at"], "%Y-%m-%d %H:%M:%S"))
        if time.time() > exp:
            conn.execute("UPDATE access_grants SET status='expired' WHERE id=?", (grant["id"],))
            db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "DATA_EXPIRED",
                                 f"grant:{grant['id']}", "Quyền truy cập đã hết hạn", request.remote_addr)
            flash("Quyền truy cập đã hết hạn. Vui lòng yêu cầu lại.", "danger")
            return redirect(url_for("admin_dashboard"))
        nonce = uuid.uuid4().hex
        db.store_nonce(conn, nonce, "admin_reveal", f"{session['username']}:{grant['id']}",
                        config.REVEAL_TOKEN_TTL_SECONDS)
    return render_template("admin_decrypt.html", record_id=record_id, grant_id=grant["id"], nonce=nonce)


@app.route("/admin/decrypt/<int:record_id>/reveal", methods=["POST"])
@login_required
@roles_required("admin")
def admin_decrypt_reveal(record_id):
    grant_id = request.form.get("grant_id")
    nonce = request.form.get("nonce", "")
    with db.get_conn() as conn:
        ok = db.consume_nonce(conn, nonce, "admin_reveal", f"{session['username']}:{grant_id}")
        if not ok:
            db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "REPLAY_DETECTED",
                                 f"grant:{grant_id}", "Token giải mã không hợp lệ/đã dùng (nghi vấn replay)",
                                 request.remote_addr)
            flash("Yêu cầu không hợp lệ hoặc đã được xử lý trước đó (khả năng bị replay).", "danger")
            return redirect(url_for("admin_dashboard"))
        grant = conn.execute("SELECT * FROM access_grants WHERE id=? AND status='approved'",
                              (grant_id,)).fetchone()
        record = conn.execute("SELECT * FROM vault_records WHERE id=?", (record_id,)).fetchone()
        if not grant or not record:
            flash("Không tìm thấy quyền truy cập hợp lệ.", "danger")
            return redirect(url_for("admin_dashboard"))
        try:
            plain = decrypt_record(record)
        except cx.IntegrityError as exc:
            db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "INTEGRITY_FAIL",
                                 f"record:{record_id}", str(exc), request.remote_addr)
            flash("Cảnh báo: bản ghi có dấu hiệu bị chỉnh sửa trái phép — từ chối hiển thị!", "danger")
            return redirect(url_for("admin_dashboard"))
        # Quyền dùng một lần (single-use grant)
        conn.execute("UPDATE access_grants SET status='used' WHERE id=?", (grant_id,))
        db.append_audit_log(conn, session["username"], "admin", session.get("sid"), "DECRYPT_SUCCESS",
                             f"record:{record_id}", f"grant:{grant_id}, lý do đã duyệt: {grant['reason']}",
                             request.remote_addr)
    plain["display_name"] = record["display_name"]
    plain["owner"] = record["owner_username"]
    return render_template("admin_decrypt_result.html", record=plain)


@app.route("/admin/benchmark")
@login_required
@roles_required("admin")
def admin_benchmark():
    results = cx.benchmark(iterations=500)
    log("BENCHMARK_RUN", None, "Chạy benchmark AES-256-GCM vs 3DES-CBC (500 vòng lặp)")
    return render_template("admin_benchmark.html", results=results)


# ---------------------------------------------------------- Auditor area
@app.route("/auditor")
@login_required
@roles_required("auditor")
def auditor_dashboard():
    with db.get_conn() as conn:
        pending = conn.execute(
            "SELECT * FROM access_grants WHERE status='pending' ORDER BY id DESC"
        ).fetchall()
        recent_grants = conn.execute(
            "SELECT * FROM access_grants WHERE status!='pending' ORDER BY id DESC LIMIT 20"
        ).fetchall()
        logs = conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("auditor_dashboard.html", pending=pending, recent_grants=recent_grants, logs=logs)


@app.route("/auditor/grant/<int:grant_id>/approve", methods=["POST"])
@login_required
@roles_required("auditor")
def auditor_approve(grant_id):
    with db.get_conn() as conn:
        expires_at = datetime.fromtimestamp(time.time() + config.GRANT_TTL_SECONDS).strftime("%Y-%m-%d %H:%M:%S")
        conn.execute(
            "UPDATE access_grants SET status='approved', decided_by=?, decided_at=?, expires_at=? WHERE id=? AND status='pending'",
            (session["username"], now_str(), expires_at, grant_id),
        )
        db.append_audit_log(conn, session["username"], "auditor", session.get("sid"), "GRANT_APPROVED",
                             f"grant:{grant_id}", f"Hết hạn lúc {expires_at}", request.remote_addr)
    flash("Đã phê duyệt yêu cầu truy cập.", "success")
    return redirect(url_for("auditor_dashboard"))


@app.route("/auditor/grant/<int:grant_id>/deny", methods=["POST"])
@login_required
@roles_required("auditor")
def auditor_deny(grant_id):
    with db.get_conn() as conn:
        conn.execute("UPDATE access_grants SET status='denied', decided_by=?, decided_at=? WHERE id=? AND status='pending'",
                     (session["username"], now_str(), grant_id))
        db.append_audit_log(conn, session["username"], "auditor", session.get("sid"), "GRANT_DENIED",
                             f"grant:{grant_id}", "Từ chối yêu cầu truy cập", request.remote_addr)
    flash("Đã từ chối yêu cầu truy cập.", "success")
    return redirect(url_for("auditor_dashboard"))


@app.route("/auditor/verify_logs")
@login_required
@roles_required("auditor")
def auditor_verify_logs():
    with db.get_conn() as conn:
        ok, broken_at = db.verify_log_chain(conn)
        db.append_audit_log(conn, session["username"], "auditor", session.get("sid"), "LOG_INTEGRITY_CHECK",
                             None, f"Kết quả: {'OK' if ok else f'LỖI tại id={broken_at}'}", request.remote_addr)
    flash(("Chuỗi audit log toàn vẹn, không phát hiện chỉnh sửa." if ok
           else f"CẢNH BÁO: audit log bị thay đổi tại bản ghi id={broken_at}!"),
          "success" if ok else "danger")
    return redirect(url_for("auditor_dashboard"))


# ------------------------------------------------------------- Error pages
@app.errorhandler(403)
def forbidden(e):
    return render_template("error.html", code=403, message="Bạn không có quyền truy cập trang này."), 403


@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", code=404, message="Không tìm thấy trang."), 404


def open_browser():
    webbrowser.open("http://127.0.0.1:5000")


if __name__ == "__main__":
    threading.Timer(1, open_browser).start()
    app.run(debug=True)
