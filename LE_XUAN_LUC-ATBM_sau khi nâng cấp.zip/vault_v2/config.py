# -*- coding: utf-8 -*-
import os
from dotenv import load_dotenv

load_dotenv()

FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY")
ROOT_SECRET = os.getenv("ROOT_SECRET")
APP_SALT = os.getenv("APP_SALT")

REVEAL_TOKEN_TTL_SECONDS = int(os.getenv("REVEAL_TOKEN_TTL_SECONDS", "60"))
GRANT_TTL_SECONDS = int(os.getenv("GRANT_TTL_SECONDS", "600"))  # 10 phút
LOGIN_MAX_FAILS = int(os.getenv("LOGIN_MAX_FAILS", "5"))
LOGIN_LOCKOUT_SECONDS = int(os.getenv("LOGIN_LOCKOUT_SECONDS", "900"))  # 15 phút

if not FLASK_SECRET_KEY or not ROOT_SECRET or not APP_SALT:
    raise ValueError(
        "Thiếu FLASK_SECRET_KEY, ROOT_SECRET hoặc APP_SALT trong file .env.\n"
        "Hãy copy .env.example -> .env và điền giá trị (xem README, mục Key Management),\n"
        "hoặc chạy: python init_db.py --gen-keys"
    )
