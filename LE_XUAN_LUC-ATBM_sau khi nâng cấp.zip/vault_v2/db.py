# -*- coding: utf-8 -*-
"""
db.py — Lớp truy cập dữ liệu (SQLite). Nâng cấp từ lưu trữ users.json (file
phẳng, không giao dịch, dễ hỏng dữ liệu) lên SQLite thật sự, có transaction
và ràng buộc khoá chính/khoá ngoại.
"""
import os
import sqlite3
import time
from contextlib import contextmanager

DB_PATH = os.environ.get("VAULT_DB_PATH", "vault.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user','admin','auditor')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vault_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_username TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    cmnd_nonce TEXT NOT NULL, cmnd_ciphertext TEXT NOT NULL, cmnd_tag TEXT NOT NULL,
    bhxh_nonce TEXT NOT NULL, bhxh_ciphertext TEXT NOT NULL, bhxh_tag TEXT NOT NULL,
    bank_nonce TEXT NOT NULL, bank_ciphertext TEXT NOT NULL, bank_tag TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    record_hmac TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (owner_username) REFERENCES users(username)
);

CREATE TABLE IF NOT EXISTS access_grants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_username TEXT NOT NULL,
    record_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','denied','used','expired')),
    requested_at TEXT NOT NULL,
    decided_by TEXT,
    decided_at TEXT,
    expires_at TEXT,
    FOREIGN KEY (record_id) REFERENCES vault_records(id)
);

CREATE TABLE IF NOT EXISTS used_nonces (
    nonce TEXT PRIMARY KEY,
    purpose TEXT NOT NULL,
    subject TEXT NOT NULL,
    issued_at REAL NOT NULL,
    expires_at REAL NOT NULL,
    used_at REAL
);

CREATE TABLE IF NOT EXISTS login_attempts (
    username TEXT PRIMARY KEY,
    fail_count INTEGER NOT NULL DEFAULT 0,
    first_fail_at REAL,
    locked_until REAL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    actor TEXT NOT NULL,
    role TEXT,
    session_id TEXT,
    event_type TEXT NOT NULL,
    target TEXT,
    detail TEXT,
    ip TEXT,
    prev_hash TEXT NOT NULL,
    entry_hash TEXT NOT NULL
);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)


# ---------------------------------------------------------------- Nonces --
def store_nonce(conn, nonce, purpose, subject, ttl_seconds=90):
    now = time.time()
    conn.execute(
        "INSERT INTO used_nonces (nonce, purpose, subject, issued_at, expires_at) VALUES (?,?,?,?,?)",
        (nonce, purpose, subject, now, now + ttl_seconds),
    )


def consume_nonce(conn, nonce, purpose, subject):
    """Trả về True nếu nonce hợp lệ, chưa dùng, chưa hết hạn -> đánh dấu đã dùng.
    Trả về False nếu nonce không tồn tại / đã dùng / hết hạn / sai purpose/subject
    (=> nghi vấn tấn công replay)."""
    row = conn.execute(
        "SELECT * FROM used_nonces WHERE nonce = ? AND purpose = ? AND subject = ?",
        (nonce, purpose, subject),
    ).fetchone()
    if not row:
        return False
    if row["used_at"] is not None:
        return False
    if time.time() > row["expires_at"]:
        return False
    conn.execute("UPDATE used_nonces SET used_at = ? WHERE nonce = ?", (time.time(), nonce))
    return True


# ------------------------------------------------------------ Login rate --
def get_login_attempt(conn, username):
    return conn.execute("SELECT * FROM login_attempts WHERE username=?", (username,)).fetchone()


def register_login_failure(conn, username, lockout_seconds=900, max_fails=5):
    row = get_login_attempt(conn, username)
    now = time.time()
    if row is None:
        conn.execute(
            "INSERT INTO login_attempts (username, fail_count, first_fail_at) VALUES (?,1,?)",
            (username, now),
        )
        return
    fail_count = row["fail_count"] + 1
    locked_until = now + lockout_seconds if fail_count >= max_fails else None
    conn.execute(
        "UPDATE login_attempts SET fail_count=?, locked_until=? WHERE username=?",
        (fail_count, locked_until, username),
    )


def reset_login_attempts(conn, username):
    conn.execute("DELETE FROM login_attempts WHERE username=?", (username,))


def is_locked_out(conn, username):
    row = get_login_attempt(conn, username)
    if not row or not row["locked_until"]:
        return False, None
    if time.time() < row["locked_until"]:
        return True, row["locked_until"]
    return False, None


# ------------------------------------------------------------- Audit log --
def append_audit_log(conn, actor, role, session_id, event_type, target, detail, ip):
    last = conn.execute("SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1").fetchone()
    prev_hash = last["entry_hash"] if last else "GENESIS"
    from crypto_utils import compute_log_entry_hash
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    entry_hash = compute_log_entry_hash(prev_hash, ts, actor, event_type, target or "", detail or "")
    conn.execute(
        """INSERT INTO audit_logs
           (timestamp, actor, role, session_id, event_type, target, detail, ip, prev_hash, entry_hash)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (ts, actor, role, session_id, event_type, target, detail, ip, prev_hash, entry_hash),
    )


def verify_log_chain(conn):
    """Tính lại toàn bộ hash-chain của audit_logs; trả về (ok: bool, broken_at: int|None)."""
    from crypto_utils import compute_log_entry_hash
    rows = conn.execute("SELECT * FROM audit_logs ORDER BY id ASC").fetchall()
    prev_hash = "GENESIS"
    for row in rows:
        expected = compute_log_entry_hash(prev_hash, row["timestamp"], row["actor"],
                                           row["event_type"], row["target"] or "", row["detail"] or "")
        if expected != row["entry_hash"] or row["prev_hash"] != prev_hash:
            return False, row["id"]
        prev_hash = row["entry_hash"]
    return True, None
