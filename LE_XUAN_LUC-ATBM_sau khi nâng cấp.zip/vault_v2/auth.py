# -*- coding: utf-8 -*-
from functools import wraps
from flask import session, redirect, url_for, flash, request

import db


def current_user():
    if "username" not in session:
        return None
    return {"username": session["username"], "role": session.get("role"), "sid": session.get("sid")}


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "username" not in session:
            flash("Vui lòng đăng nhập trước!", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def roles_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "username" not in session:
                flash("Vui lòng đăng nhập trước!", "danger")
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                with db.get_conn() as conn:
                    db.append_audit_log(
                        conn, session.get("username"), session.get("role"), session.get("sid"),
                        "PERMISSION_DENIED", request.path,
                        f"Yêu cầu vai trò {roles}, thực tế: {session.get('role')}",
                        request.remote_addr,
                    )
                flash("Bạn không có quyền truy cập chức năng này!", "danger")
                return redirect(url_for("home"))
            return f(*args, **kwargs)
        return wrapper
    return decorator
