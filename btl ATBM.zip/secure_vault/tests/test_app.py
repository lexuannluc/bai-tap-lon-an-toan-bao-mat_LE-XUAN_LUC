"""
test_app.py
------------
Test các yêu cầu bắt buộc của đề bài (mục 12.3.0.9 Kiểm thử bắt buộc):
  - User tạo dữ liệu nhạy cảm.
  - User xem dữ liệu của mình.
  - Admin không có quyền giải mã nếu chưa được cấp quyền.
  - Auditor xem log nhưng không xem dữ liệu nhạy cảm.
  - Sửa ciphertext trong database -> phát hiện lỗi toàn vẹn.
  - Kiểm tra log giải mã được ghi lại.

Chạy: pytest -v
"""
import os
import sys
import importlib

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


@pytest.fixture()
def client(tmp_path, monkeypatch):
    # Mỗi test dùng 1 database + master key riêng, độc lập, không ảnh hưởng lẫn nhau
    db_file = tmp_path / "test_vault.db"
    key_file = tmp_path / "test_master.key"
    monkeypatch.setattr("database.DB_PATH", str(db_file))

    import crypto_utils
    monkeypatch.setattr(crypto_utils, "MASTER_KEY_FILE", str(key_file))
    monkeypatch.setattr(crypto_utils, "_MASTER_KEY", crypto_utils._load_or_create_master_key())

    import app as flask_app_module
    importlib.reload(flask_app_module)
    flask_app_module.app.config["TESTING"] = True
    with flask_app_module.app.test_client() as c:
        yield c


def register(client, username, password, role):
    return client.post("/api/register", json={"username": username, "password": password, "role": role})


def login(client, username, password):
    return client.post("/api/login", json={"username": username, "password": password})


# ---------------------------------------------------------------------------
def test_user_creates_and_views_own_data(client):
    register(client, "alice", "alicepw123", "user")
    login(client, "alice", "alicepw123")

    r = client.post("/api/data", json={"field_name": "phone", "value": "0987654321"})
    assert r.status_code == 200
    rid = r.get_json()["id"]

    r = client.get("/api/data")
    rows = r.get_json()
    assert any(row["id"] == rid and row["value"] == "0987654321" and row["status"] == "decrypted"
               for row in rows)


def test_user_cannot_see_other_users_data(client):
    register(client, "alice", "alicepw123", "user")
    register(client, "bob", "bobpassword", "user")

    login(client, "alice", "alicepw123")
    client.post("/api/data", json={"field_name": "email", "value": "alice@example.com"})
    client.post("/api/logout")

    login(client, "bob", "bobpassword")
    r = client.get("/api/data")
    rows = r.get_json()
    assert all(row["value"] != "alice@example.com" for row in rows)


def test_admin_cannot_decrypt_without_grant(client):
    register(client, "alice", "alicepw123", "user")
    register(client, "admin1", "adminpass1", "admin")

    login(client, "alice", "alicepw123")
    r = client.post("/api/data", json={"field_name": "id_card", "value": "001199012345"})
    rid = r.get_json()["id"]
    client.post("/api/logout")

    login(client, "admin1", "adminpass1")
    r = client.post(f"/api/data/{rid}/decrypt")
    assert r.status_code == 403
    assert "quyền" in r.get_json()["error"]


def test_admin_can_decrypt_after_grant(client):
    register(client, "alice", "alicepw123", "user")
    register(client, "admin1", "adminpass1", "admin")

    login(client, "alice", "alicepw123")
    r = client.post("/api/data", json={"field_name": "id_card", "value": "001199012345"})
    rid = r.get_json()["id"]
    client.post("/api/logout")

    login(client, "admin1", "adminpass1")
    g = client.post(f"/api/data/{rid}/grant")
    assert g.status_code == 200

    r = client.post(f"/api/data/{rid}/decrypt")
    assert r.status_code == 200
    assert r.get_json()["value"] == "001199012345"


def test_auditor_sees_log_but_not_sensitive_data(client):
    register(client, "auditor1", "auditorpass", "auditor")
    login(client, "auditor1", "auditorpass")

    r = client.get("/api/data")
    assert r.status_code == 403

    r = client.get("/api/audit-log")
    assert r.status_code == 200
    assert isinstance(r.get_json(), list)


def test_tampered_ciphertext_detected(client):
    register(client, "alice", "alicepw123", "user")
    login(client, "alice", "alicepw123")
    r = client.post("/api/data", json={"field_name": "phone", "value": "0911222333"})
    rid = r.get_json()["id"]
    client.post("/api/logout")

    register(client, "admin1", "adminpass1", "admin")
    login(client, "admin1", "adminpass1")
    client.post(f"/api/data/{rid}/grant")
    client.post(f"/api/data/{rid}/tamper")

    r = client.post(f"/api/data/{rid}/decrypt")
    assert r.status_code == 400
    assert "toàn vẹn" in r.get_json()["error"].lower()


def test_decrypt_actions_are_logged(client):
    register(client, "alice", "alicepw123", "user")
    register(client, "admin1", "adminpass1", "admin")
    register(client, "auditor1", "auditorpass", "auditor")

    login(client, "alice", "alicepw123")
    r = client.post("/api/data", json={"field_name": "phone", "value": "0911000111"})
    rid = r.get_json()["id"]
    client.post("/api/logout")

    login(client, "admin1", "adminpass1")
    client.post(f"/api/data/{rid}/grant")
    client.post(f"/api/data/{rid}/decrypt")
    client.post("/api/logout")

    login(client, "auditor1", "auditorpass")
    r = client.get("/api/audit-log")
    actions = [row["action"] for row in r.get_json()]
    assert "DECRYPT_SUCCESS" in actions
    assert "GRANT_CREATED" in actions


def test_login_failure_logged(client):
    register(client, "alice", "alicepw123", "user")
    r = login(client, "alice", "wrongpassword")
    assert r.status_code == 401

    register(client, "auditor1", "auditorpass", "auditor")
    login(client, "auditor1", "auditorpass")
    r = client.get("/api/audit-log")
    actions = [row["action"] for row in r.get_json()]
    assert "LOGIN_FAILED" in actions
