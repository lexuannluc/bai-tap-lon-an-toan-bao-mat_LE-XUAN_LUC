"""
legacy_demo.py
---------------
CHỈ DÙNG ĐỂ MINH HỌA / SO SÁNH thuật toán cũ TripleDES với AES-GCM hiện đại.
KHÔNG được dùng để bảo vệ dữ liệu thật trong hệ thống (xem báo cáo, mục so sánh).

TripleDES (3DES):
- Kích thước khối 64 bit (AES là 128 bit) => dễ bị tấn công birthday (Sweet32)
  khi mã hóa nhiều dữ liệu với cùng khóa.
- Không có sẵn cơ chế xác thực (AEAD) như AES-GCM => phải tự ghép thêm HMAC
  nếu muốn đảm bảo toàn vẹn (Encrypt-then-MAC).
- Tốc độ chậm hơn AES nhiều lần vì không có tăng tốc phần cứng (AES-NI).
- NIST đã loại bỏ TripleDES khỏi danh sách khuyến nghị từ 2023.

File này dùng `cryptography` (CBC mode + PKCS7 padding) + HMAC-SHA256 riêng
để minh họa cách làm "đúng tối thiểu" với thuật toán cũ, dùng cho mục đích
so sánh hiệu năng / độ an toàn trong báo cáo.
"""

import os
import hmac
import hashlib

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding


def tripledes_encrypt_then_mac(key24: bytes, mac_key: bytes, plaintext: bytes):
    """key24: 24 byte (3DES key). mac_key: dùng cho HMAC-SHA256 (Encrypt-then-MAC)."""
    iv = os.urandom(8)  # block size của DES = 8 byte
    padder = padding.PKCS7(64).padder()
    padded = padder.update(plaintext) + padder.finalize()

    cipher = Cipher(algorithms.TripleDES(key24), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ct = encryptor.update(padded) + encryptor.finalize()

    tag = hmac.new(mac_key, iv + ct, hashlib.sha256).digest()
    return iv, ct, tag


def tripledes_verify_and_decrypt(key24: bytes, mac_key: bytes, iv: bytes, ct: bytes, tag: bytes):
    expected_tag = hmac.new(mac_key, iv + ct, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("HMAC không khớp - dữ liệu có thể đã bị sửa đổi (TripleDES không tự có AEAD)")

    cipher = Cipher(algorithms.TripleDES(key24), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded = decryptor.update(ct) + decryptor.finalize()
    unpadder = padding.PKCS7(64).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


if __name__ == "__main__":
    key24 = os.urandom(24)
    mac_key = os.urandom(32)
    msg = b"Demo so sanh TripleDES vs AES-GCM - khong dung de bao ve du lieu that"

    iv, ct, tag = tripledes_encrypt_then_mac(key24, mac_key, msg)
    print("Ciphertext (hex):", ct.hex())

    recovered = tripledes_verify_and_decrypt(key24, mac_key, iv, ct, tag)
    print("Giải mã thành công:", recovered.decode())

    # Demo phát hiện sửa đổi
    try:
        tampered = bytearray(ct)
        tampered[0] ^= 0xFF
        tripledes_verify_and_decrypt(key24, mac_key, iv, bytes(tampered), tag)
    except ValueError as e:
        print("Phát hiện tấn công sửa ciphertext:", e)
