"""
app.py
-------
Secure Personal Data Vault - Flask backend.

Phân quyền (RBAC) tối thiểu theo đề bài:
  - user    : tạo dữ liệu nhạy cảm của chính mình, xem (giải mã) dữ liệu của chính mình.
  - admin   : KHÔNG mặc định xem được dữ liệu nhạy cảm. Chỉ giải mã được record
              nào đã được cấp quyền tường minh (decrypt_grants) bởi chính admin
              đó cấp cho mình (mô phỏng quy trình "self-service phê duyệt" đơn giản,
              trong thực tế nên có người khác duyệt - xem README hạn chế biết).
  - auditor : chỉ xem được audit log (không xem được sensitive_data, dù mã hóa
              hay giải mã).

Mọi lần GIẢI MÃ dữ liệu nhạy cảm đều bị ghi audit log (ai, lúc nào, record nào).
Mọi lần đăng nhập (thành công / thất bại), cấp quyền, lỗi toàn vẹn dữ liệu cũng
được ghi log.
"""

import functools
import datetime

from flask import Flask, request, jsonify, session, send_from_directory
import bcrypt
from cryptography.exceptions import InvalidTag

import database as db
import crypto_utils as crypto

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.secret_key = crypto._MASTER_KEY[:16]  # chỉ dùng để ký session cookie (không phải DEK)

db.init_db()


# ---------------------------------------------------------------------------
# Audit log helper
# ---------------------------------------------------------------------------
def write_audit(actor_id, actor_role, action, target_id=None, detail=""):
    conn = db.get_conn()
    prev_hash = db.last_log_hash(conn)
    entry = f"{actor_id}|{actor_role}|{action}|{target_id}|{detail}|{db.now()}"
    entry_hash = crypto.hmac_log_chain(prev_hash, entry)
    conn.execute(
        """INSERT INTO audit_log
           (actor_id, actor_role, action, target_id, detail, prev_hash, entry_hash, created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (actor_id, actor_role, action, target_id, detail, prev_hash, entry_hash, db.now()),
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Auth helpers / decorators
# ---------------------------------------------------------------------------
def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    conn = db.get_conn()
    u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return u


def login_required(f):
    @functools.wraps(f)
    def wrapper(*a, **kw):
        if not current_user():
            return jsonify({"error": "Chưa đăng nhập"}), 401
        return f(*a, **kw)
    return wrapper


def role_required(*roles):
    def deco(f):
        @functools.wraps(f)
        def wrapper(*a, **kw):
            u = current_user()
            if not u:
                return jsonify({"error": "Chưa đăng nhập"}), 401
            if u["role"] not in roles:
                write_audit(u["id"], u["role"], "ACCESS_DENIED", None,
                            f"endpoint={request.path}")
                return jsonify({"error": "Không có quyền truy cập"}), 403
            return f(*a, **kw)
        return wrapper
    return deco


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory("static", "index.html")


# ---------------------------------------------------------------------------
# Auth endpoints
# ---------------------------------------------------------------------------
@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "")
    role = data.get("role", "user")

    if role not in ("user", "admin", "auditor"):
        return jsonify({"error": "Role không hợp lệ"}), 400
    if len(username) < 3 or len(password) < 6:
        return jsonify({"error": "Username >=3 ký tự, mật khẩu >=6 ký tự"}), 400

    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn = db.get_conn()
    try:
        conn.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?,?,?,?)",
            (username, pw_hash, role, db.now()),
        )
        conn.commit()
    except Exception:
        conn.close()
        return jsonify({"error": "Username đã tồn tại"}), 400
    uid = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()["id"]
    conn.close()
    write_audit(uid, role, "REGISTER", uid, f"username={username}")
    return jsonify({"ok": True})


@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    username = data.get("username", "")
    password = data.get("password", "")

    conn = db.get_conn()
    u = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()

    if not u or not bcrypt.checkpw(password.encode(), u["password_hash"].encode()):
        write_audit(u["id"] if u else None, u["role"] if u else "unknown",
                    "LOGIN_FAILED", None, f"username={username}")
        return jsonify({"error": "Sai username hoặc mật khẩu"}), 401

    session["uid"] = u["id"]
    write_audit(u["id"], u["role"], "LOGIN_SUCCESS", u["id"], "")
    return jsonify({"ok": True, "username": u["username"], "role": u["role"]})


@app.route("/api/logout", methods=["POST"])
@login_required
def logout():
    u = current_user()
    write_audit(u["id"], u["role"], "LOGOUT", u["id"], "")
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/me")
def me():
    u = current_user()
    if not u:
        return jsonify({"authenticated": False})
    return jsonify({"authenticated": True, "username": u["username"], "role": u["role"], "id": u["id"]})


# ---------------------------------------------------------------------------
# Sensitive data endpoints (user)
# ---------------------------------------------------------------------------
@app.route("/api/data", methods=["POST"])
@role_required("user")
def create_data():
    u = current_user()
    data = request.get_json(force=True)
    field_name = data.get("field_name", "").strip()
    value = data.get("value", "")
    if not field_name or not value:
        return jsonify({"error": "Thiếu field_name hoặc value"}), 400

    # AAD gắn field_name + owner_id để chống đổi chỗ ciphertext giữa các bản ghi
    aad = f"{u['id']}:{field_name}".encode()
    ciphertext = crypto.encrypt_field(u["id"], value, aad=aad)

    conn = db.get_conn()
    cur = conn.execute(
        "INSERT INTO sensitive_data (owner_id, field_name, ciphertext, created_at) VALUES (?,?,?,?)",
        (u["id"], field_name, ciphertext, db.now()),
    )
    conn.commit()
    rid = cur.lastrowid
    conn.close()
    write_audit(u["id"], u["role"], "DATA_CREATE", rid, f"field={field_name}")
    return jsonify({"ok": True, "id": rid})


@app.route("/api/data", methods=["GET"])
@login_required
def list_data():
    """user: chỉ thấy record của chính mình (đã giải mã).
    admin: thấy danh sách record của TẤT CẢ user nhưng KHÔNG giải mã được nếu
           chưa có grant (trả về '***ENCRYPTED***').
    auditor: không có quyền xem endpoint này (chỉ xem log)."""
    u = current_user()
    if u["role"] == "auditor":
        write_audit(u["id"], u["role"], "ACCESS_DENIED", None, "auditor cannot view sensitive_data")
        return jsonify({"error": "Auditor không có quyền xem dữ liệu nhạy cảm"}), 403

    conn = db.get_conn()
    if u["role"] == "user":
        rows = conn.execute(
            "SELECT * FROM sensitive_data WHERE owner_id=? ORDER BY id DESC", (u["id"],)
        ).fetchall()
    else:  # admin
        rows = conn.execute("SELECT * FROM sensitive_data ORDER BY id DESC").fetchall()

    result = []
    for r in rows:
        item = {"id": r["id"], "owner_id": r["owner_id"], "field_name": r["field_name"],
                 "created_at": r["created_at"]}
        if u["role"] == "user":
            try:
                aad = f"{r['owner_id']}:{r['field_name']}".encode()
                item["value"] = crypto.decrypt_field(r["owner_id"], r["ciphertext"], aad=aad)
                item["status"] = "decrypted"
            except InvalidTag:
                item["value"] = None
                item["status"] = "INTEGRITY_FAILED"
                write_audit(u["id"], u["role"], "INTEGRITY_FAILURE", r["id"], "tag mismatch on list")
        else:  # admin: chưa biết có grant hay chưa -> chỉ trả về trạng thái ẩn
            grant = conn.execute(
                """SELECT * FROM decrypt_grants WHERE admin_id=? AND record_id=?
                   AND (expires_at IS NULL OR expires_at > ?)""",
                (u["id"], r["id"], db.now()),
            ).fetchone()
            item["value"] = "***ENCRYPTED***"
            item["status"] = "grant_available" if grant else "no_grant"
        result.append(item)
    conn.close()
    return jsonify(result)


@app.route("/api/data/<int:record_id>/grant", methods=["POST"])
@role_required("admin")
def request_grant(record_id):
    """Admin tự cấp quyền giải mã cho chính mình đối với 1 record cụ thể.
    (Mô phỏng đơn giản hóa quy trình "break-glass" có ghi log đầy đủ; trong hệ
    thống thật nên yêu cầu người khác/2nd-approver duyệt - xem README)."""
    u = current_user()
    conn = db.get_conn()
    rec = conn.execute("SELECT * FROM sensitive_data WHERE id=?", (record_id,)).fetchone()
    if not rec:
        conn.close()
        return jsonify({"error": "Không tìm thấy record"}), 404

    expires = (datetime.datetime.utcnow() + datetime.timedelta(minutes=10)).isoformat()
    conn.execute(
        "INSERT INTO decrypt_grants (admin_id, record_id, granted_by, expires_at, created_at) VALUES (?,?,?,?,?)",
        (u["id"], record_id, u["id"], expires, db.now()),
    )
    conn.commit()
    conn.close()
    write_audit(u["id"], u["role"], "GRANT_CREATED", record_id, f"expires_at={expires}")
    return jsonify({"ok": True, "expires_at": expires})


@app.route("/api/data/<int:record_id>/decrypt", methods=["POST"])
@role_required("admin")
def admin_decrypt(record_id):
    u = current_user()
    conn = db.get_conn()
    grant = conn.execute(
        """SELECT * FROM decrypt_grants WHERE admin_id=? AND record_id=?
           AND (expires_at IS NULL OR expires_at > ?)""",
        (u["id"], record_id, db.now()),
    ).fetchone()
    if not grant:
        conn.close()
        write_audit(u["id"], u["role"], "DECRYPT_DENIED", record_id, "no valid grant")
        return jsonify({"error": "Admin chưa được cấp quyền giải mã record này"}), 403

    rec = conn.execute("SELECT * FROM sensitive_data WHERE id=?", (record_id,)).fetchone()
    conn.close()
    if not rec:
        return jsonify({"error": "Không tìm thấy record"}), 404

    try:
        aad = f"{rec['owner_id']}:{rec['field_name']}".encode()
        value = crypto.decrypt_field(rec["owner_id"], rec["ciphertext"], aad=aad)
    except InvalidTag:
        write_audit(u["id"], u["role"], "INTEGRITY_FAILURE", record_id, "tag mismatch on admin decrypt")
        return jsonify({"error": "Toàn vẹn dữ liệu thất bại - ciphertext có thể đã bị sửa đổi"}), 400

    write_audit(u["id"], u["role"], "DECRYPT_SUCCESS", record_id, f"field={rec['field_name']}")
    return jsonify({"ok": True, "value": value})


# ---------------------------------------------------------------------------
# Audit log endpoint (auditor + admin)
# ---------------------------------------------------------------------------
@app.route("/api/audit-log", methods=["GET"])
@role_required("auditor", "admin")
def get_audit_log():
    conn = db.get_conn()
    rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# ---------------------------------------------------------------------------
# Debug-only endpoint to simulate tampering with ciphertext in DB (for demo/tests)
# ---------------------------------------------------------------------------
@app.route("/api/data/<int:record_id>/tamper", methods=["POST"])
@role_required("admin")
def tamper_record(record_id):
    """Endpoint DEMO: cố tình sửa 1 ký tự trong ciphertext để minh họa cơ chế
    phát hiện toàn vẹn của AES-GCM. CHỈ DÙNG ĐỂ KIỂM THỬ, không có trong hệ
    thống production thật."""
    u = current_user()
    conn = db.get_conn()
    rec = conn.execute("SELECT * FROM sensitive_data WHERE id=?", (record_id,)).fetchone()
    if not rec:
        conn.close()
        return jsonify({"error": "not found"}), 404
    ct = list(rec["ciphertext"])
    # đổi ký tự cuối cùng để phá vỡ tag xác thực
    ct[-2] = "A" if ct[-2] != "A" else "B"
    new_ct = "".join(ct)
    conn.execute("UPDATE sensitive_data SET ciphertext=? WHERE id=?", (new_ct, record_id))
    conn.commit()
    conn.close()
    write_audit(u["id"], u["role"], "DEMO_TAMPER", record_id, "ciphertext intentionally corrupted for test")
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
