"""
crypto_utils.py
----------------
Module mã hóa cho Secure Personal Data Vault.

Thuật toán chính: AES-256-GCM (mã hóa có xác thực - AEAD).
- AES-GCM cung cấp cả tính bảo mật (confidentiality) và toàn vẹn (integrity)
  trong một bước: nếu ciphertext hoặc tag bị sửa, decrypt() sẽ ném exception.
- Mỗi lần mã hóa dùng một NONCE (IV) ngẫu nhiên 12 byte, KHÔNG bao giờ tái sử
  dụng nonce với cùng một khóa (yêu cầu bắt buộc của GCM).

Quản lý khóa (Key Management):
- Có một MASTER KEY (32 byte, AES-256) được nạp từ biến môi trường
  VAULT_MASTER_KEY (base64). Nếu không có, sinh ngẫu nhiên và lưu vào file
  `master.key` (chỉ owner mới đọc được, mode 600) - mô phỏng KMS/HSM cục bộ.
  Trong môi trường production thật, khóa này nên được lưu trong KMS
  (AWS KMS, HashiCorp Vault, Azure Key Vault...) chứ KHÔNG lưu cùng code/database.
- Mỗi user có một khóa dữ liệu riêng (Data Encryption Key - DEK) được dẫn xuất
  từ Master Key bằng HKDF-SHA256, dùng salt = user_id. Đây gọi là kiến trúc
  "envelope encryption" đơn giản: Master Key bảo vệ DEK, DEK mã hóa dữ liệu.
  => Nếu cần thu hồi/xoay khóa cho 1 user, chỉ cần đổi salt/derive lại mà
     không ảnh hưởng user khác.
- TripleDES (3DES) chỉ được cài đặt trong legacy_demo.py để MINH HỌA thuật
  toán cũ / so sánh hiệu năng & độ an toàn, KHÔNG dùng để bảo vệ dữ liệu thật.
"""

import os
import base64
import hashlib
import hmac as hmac_module

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes

MASTER_KEY_ENV = "VAULT_MASTER_KEY"
MASTER_KEY_FILE = os.path.join(os.path.dirname(__file__), "master.key")


def _load_or_create_master_key() -> bytes:
    """Nạp master key từ biến môi trường, hoặc từ file cục bộ (tạo mới nếu chưa có).
    KHÔNG hard-code khóa trong mã nguồn (đúng yêu cầu bắt buộc)."""
    env_val = os.environ.get(MASTER_KEY_ENV)
    if env_val:
        return base64.b64decode(env_val)

    if os.path.exists(MASTER_KEY_FILE):
        with open(MASTER_KEY_FILE, "rb") as f:
            return base64.b64decode(f.read())

    # Sinh khóa mới ngẫu nhiên 256-bit
    key = AESGCM.generate_key(bit_length=256)
    with open(MASTER_KEY_FILE, "wb") as f:
        f.write(base64.b64encode(key))
    os.chmod(MASTER_KEY_FILE, 0o600)  # chỉ chủ sở hữu file mới đọc/ghi được
    return key


_MASTER_KEY = _load_or_create_master_key()


def derive_user_dek(user_id: int) -> bytes:
    """Dẫn xuất Data Encryption Key (DEK) riêng cho từng user từ Master Key,
    dùng HKDF-SHA256. salt gắn với user_id => mỗi user có khóa khác nhau,
    nhưng không ai cần lưu trữ thêm khóa nào (derive on the fly)."""
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=str(user_id).encode("utf-8"),
        info=b"secure-vault-dek-v1",
    )
    return hkdf.derive(_MASTER_KEY)


def encrypt_field(user_id: int, plaintext: str, aad: bytes = b"") -> str:
    """Mã hóa một trường dữ liệu nhạy cảm bằng AES-256-GCM.
    aad (Additional Authenticated Data) ví dụ field_name -> chống đổi chỗ
    ciphertext giữa các trường khác nhau.
    Trả về chuỗi base64 gồm: nonce (12 byte) || ciphertext+tag.
    """
    key = derive_user_dek(user_id)
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)  # 96-bit nonce ngẫu nhiên, không tái sử dụng
    ct = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), aad)
    blob = nonce + ct
    return base64.b64encode(blob).decode("utf-8")


def decrypt_field(user_id: int, b64_blob: str, aad: bytes = b"") -> str:
    """Giải mã. Nếu ciphertext/tag bị sửa đổi (mất toàn vẹn) hoặc sai khóa,
    AESGCM sẽ ném cryptography.exceptions.InvalidTag."""
    key = derive_user_dek(user_id)
    aesgcm = AESGCM(key)
    raw = base64.b64decode(b64_blob)
    nonce, ct = raw[:12], raw[12:]
    pt = aesgcm.decrypt(nonce, ct, aad)
    return pt.decode("utf-8")


def hmac_log_chain(prev_hash: str, entry: str) -> str:
    """Tạo hash chain cho audit log (mỗi dòng log chứa hash của dòng trước)
    để phát hiện việc log bị sửa/xóa sau khi ghi."""
    h = hashlib.sha256()
    h.update((prev_hash + entry).encode("utf-8"))
    return h.hexdigest()
