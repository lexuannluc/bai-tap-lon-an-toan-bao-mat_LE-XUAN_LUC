"""
database.py
------------
Lớp truy cập SQLite cho Secure Personal Data Vault.

Schema:
  users(id, username, password_hash, role, created_at)
      role in ('user', 'admin', 'auditor')

  sensitive_data(id, owner_id, field_name, ciphertext, created_at)
      ciphertext = base64(nonce || AESGCM(plaintext))  -- xem crypto_utils.py
      KHÔNG có cột nào lưu plaintext.

  decrypt_grants(id, admin_id, record_id, granted_by, expires_at, created_at)
      Cấp quyền TẠM THỜI cho 1 admin được giải mã 1 record cụ thể.
      Mặc định admin KHÔNG có quyền giải mã bất kỳ record nào.

  audit_log(id, actor_id, actor_role, action, target_id, detail,
            prev_hash, entry_hash, created_at)
      Mọi hành động đăng nhập / giải mã / cấp quyền / lỗi đều được ghi lại.
      entry_hash = SHA256(prev_hash + nội dung dòng) -> tạo hash-chain,
      giúp phát hiện nếu ai đó cố sửa/xóa một dòng log cũ.
      Log KHÔNG BAO GIỜ chứa plaintext, mật khẩu hay khóa bí mật.
"""

import sqlite3
import datetime
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "vault.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user','admin','auditor')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sensitive_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    field_name TEXT NOT NULL,
    ciphertext TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(owner_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS decrypt_grants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    record_id INTEGER NOT NULL,
    granted_by INTEGER NOT NULL,
    expires_at TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(admin_id) REFERENCES users(id),
    FOREIGN KEY(record_id) REFERENCES sensitive_data(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id INTEGER,
    actor_role TEXT,
    action TEXT NOT NULL,
    target_id INTEGER,
    detail TEXT,
    prev_hash TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def now():
    return datetime.datetime.utcnow().isoformat()


def last_log_hash(conn):
    row = conn.execute(
        "SELECT entry_hash FROM audit_log ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return row["entry_hash"] if row else "GENESIS"
